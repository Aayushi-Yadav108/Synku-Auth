package synku_admin_main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AdminMainApplication {

	public static void main(String[] args) {
		SpringApplication.run(AdminMainApplication.class, args);
	}

}
