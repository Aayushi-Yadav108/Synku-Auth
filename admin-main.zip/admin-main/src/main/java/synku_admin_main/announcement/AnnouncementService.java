package synku_admin_main.announcement;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class AnnouncementService {

	private final AnnouncementRepository repository;

	public AnnouncementService(AnnouncementRepository repository) {
		this.repository = repository;
	}

	@Transactional(readOnly = true)
	public List<AnnouncementResponse> getAll() {
		return repository.findAll()
				.stream()
				.map(AnnouncementResponse::fromEntity)
				.toList();
	}

	@Transactional
	public AnnouncementResponse create(CreateAnnouncementRequest request) {
		Announcement announcement = new Announcement(
				request.title(),
				request.message(),
				request.authorName()
		);

		Announcement saved = repository.save(announcement);
		return AnnouncementResponse.fromEntity(saved);
	}

	@Transactional
	public void delete(Long id) {
		if (!repository.existsById(id)) {
			throw new AnnouncementServiceException("Announcement with id %d not found".formatted(id));
		}
		repository.deleteById(id);
	}
}

