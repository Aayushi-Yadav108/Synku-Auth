package synku_admin_main.announcement;

import java.time.OffsetDateTime;

record AnnouncementResponse(
		Long id,
		String title,
		String message,
		String authorName,
		OffsetDateTime createdAt
) {
	static AnnouncementResponse fromEntity(Announcement announcement) {
		return new AnnouncementResponse(
				announcement.getId(),
				announcement.getTitle(),
				announcement.getMessage(),
				announcement.getAuthorName(),
				announcement.getCreatedAt()
		);
	}
}

