package synku_admin_main.announcement;

class AnnouncementServiceException extends RuntimeException {
	AnnouncementServiceException(String message) {
		super(message);
	}
}

