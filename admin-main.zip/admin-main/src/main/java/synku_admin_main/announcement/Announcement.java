package synku_admin_main.announcement;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;

import java.time.OffsetDateTime;

/**
 * Represents an announcement that can be displayed on the admin dashboard.
 */
@Entity
@Table(name = "announcements")
public class Announcement {

	private static final int TITLE_MAX_LENGTH = 180;
	private static final int AUTHOR_MAX_LENGTH = 80;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(nullable = false, length = TITLE_MAX_LENGTH)
	private String title;

	@Column(nullable = false, columnDefinition = "TEXT")
	private String message;

	@Column(nullable = false, length = AUTHOR_MAX_LENGTH)
	private String authorName;

	@Column(nullable = false)
	private OffsetDateTime createdAt;

	protected Announcement() {
		// JPA only
	}

	public Announcement(String title, String message, String authorName) {
		this.title = title;
		this.message = message;
		this.authorName = authorName;
	}

	@PrePersist
	public void onCreate() {
		if (createdAt == null) {
			createdAt = OffsetDateTime.now();
		}
	}

	public Long getId() {
		return id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getAuthorName() {
		return authorName;
	}

	public void setAuthorName(String authorName) {
		this.authorName = authorName;
	}

	public OffsetDateTime getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(OffsetDateTime createdAt) {
		this.createdAt = createdAt;
	}
}

