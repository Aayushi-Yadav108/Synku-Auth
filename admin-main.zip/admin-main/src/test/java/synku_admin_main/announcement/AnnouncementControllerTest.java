package synku_admin_main.announcement;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
@AutoConfigureTestDatabase(replace = Replace.ANY)
class AnnouncementControllerTest {

	@Autowired
	private MockMvc mockMvc;

	@Autowired
	private ObjectMapper objectMapper;

	@Test
	void createListAndDeleteAnnouncement() throws Exception {
		CreateAnnouncementRequest request = new CreateAnnouncementRequest(
				"Campus Update",
				"New event announced",
				"Admin"
		);

		String json = objectMapper.writeValueAsString(request);

		String responseBody = mockMvc.perform(post("/api/announcements")
						.contentType(MediaType.APPLICATION_JSON)
						.content(json))
				.andExpect(status().isCreated())
				.andExpect(jsonPath("$.id").exists())
				.andExpect(jsonPath("$.title").value("Campus Update"))
				.andReturn()
				.getResponse()
				.getContentAsString();

		mockMvc.perform(get("/api/announcements"))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$[0].title").value("Campus Update"));

		Long id = objectMapper.readTree(responseBody).get("id").asLong();

		mockMvc.perform(delete("/api/announcements/{id}", id))
				.andExpect(status().isNoContent());

		mockMvc.perform(delete("/api/announcements/{id}", id))
				.andExpect(status().isNotFound());
	}
}

