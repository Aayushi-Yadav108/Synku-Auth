package synku_admin_main;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdminMainApplicationTests {

	@Test
	void contextLoads() {
	}

}
